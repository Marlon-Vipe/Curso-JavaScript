//npm install @babel/cli @babel/core @babel/polyfill @babel/preset-env @babel/register gulp gulp-babel gulp-concat gulp-plumber gulp-uglify --save-dev

const numbers = [1, 2, 3, 4]

const printNumbers = () => {
    console.log(...numbers)
}